package progii.juegotablero.model.ajedrez.piezas;

import list.ArrayList;
import list.IList;
import progii.juegotablero.model.Casilla;
import progii.juegotablero.model.Jugador;
import progii.juegotablero.model.ajedrez.PiezaAjedrez;
import progii.juegotablero.model.ajedrez.TipoPiezaAjedrez;

public class Reina extends PiezaAjedrez {
    
    public Reina(Jugador jugador, int fila, char columna){
        super(jugador, TipoPiezaAjedrez.REINA, fila, columna);
    }

    @Override
    public IList<Casilla> movimientosValidos(){
        IList<Casilla> resultado = new ArrayList<>();

        // Verticales
        casillasVisitables(resultado, -1, 0);
        casillasVisitables(resultado, 0, -1);
        casillasVisitables(resultado, 1, 0);
        casillasVisitables(resultado, 0, 1);
        // Diagonales
        casillasVisitables(resultado, 1, 1);
        casillasVisitables(resultado, -1, -1);
        casillasVisitables(resultado, 1, -1);
        casillasVisitables(resultado, -1, 1);

        return resultado;
    }
}