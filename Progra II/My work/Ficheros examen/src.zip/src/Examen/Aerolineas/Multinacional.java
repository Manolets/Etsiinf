public class Multinacional extends Aerolinea{
    
}