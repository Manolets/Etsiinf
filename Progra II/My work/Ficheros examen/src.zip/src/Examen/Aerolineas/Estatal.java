package Examen.Aerolineas;

public class Estatal extends Aerolinea {
    
}