package progii.juegotablero.model.ajedrez.piezas;

import list.ArrayList;
import list.IList;
import progii.juegotablero.model.Casilla;
import progii.juegotablero.model.Jugador;
import progii.juegotablero.model.ajedrez.PiezaAjedrez;
import progii.juegotablero.model.ajedrez.TipoPiezaAjedrez;

public class Rey extends PiezaAjedrez {
    
    public Rey(Jugador jugador, int fila, char columna){
        super(jugador, TipoPiezaAjedrez.REY, fila, columna);
    }

    @Override
    public IList<Casilla> movimientosValidos() {
        IList<Casilla> resultado = new ArrayList<>();

        casillaVisitable(resultado, getFila() + 1, getColumna());
        casillaVisitable(resultado, getFila() - 1, getColumna());
        casillaVisitable(resultado, getFila() + 1, getColumna() + 1);
        casillaVisitable(resultado, getFila(), getColumna() + 1);
        casillaVisitable(resultado, getFila() - 1, getColumna() + 1);
        casillaVisitable(resultado, getFila() + 1, getColumna() - 1);
        casillaVisitable(resultado, getFila(), getColumna() - 1);
        casillaVisitable(resultado, getFila() - 1, getColumna() - 1);

        return resultado;
    }
}