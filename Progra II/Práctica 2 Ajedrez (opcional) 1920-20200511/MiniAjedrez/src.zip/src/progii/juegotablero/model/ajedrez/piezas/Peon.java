package progii.juegotablero.model.ajedrez.piezas;

import list.ArrayList;
import list.IList;
import progii.juegotablero.model.Casilla;
import progii.juegotablero.model.Jugador;
import progii.juegotablero.model.ajedrez.PiezaAjedrez;
import progii.juegotablero.model.ajedrez.TipoPiezaAjedrez;

public class Peon extends PiezaAjedrez {
    
    public Peon(Jugador jugador, int fila, char columna){
        super(jugador, TipoPiezaAjedrez.PEON, fila, columna);
    }

    @Override
    public IList<Casilla> movimientosValidos() {
        IList<Casilla> resultado = new ArrayList<>();
        int var = getJugador().getNombre().equals("BLANCO")? - 1: 1;
        if (queHay(getFila() + var, getColumna()) == null)
            casillaVisitable(resultado, getFila() + var, getColumna());
        
        if (queHay(getFila() + var, getColumna() + var) != null){
            if (queHay(getFila() + var, getColumna() + var).getJugador() != getJugador())
                casillaVisitable(resultado, getFila() + var, getColumna() + var);
        }

        if (queHay(getFila() + var, getColumna() - var) != null){
            if (queHay(getFila() + var, getColumna() - var).getJugador() != getJugador())
                casillaVisitable(resultado, getFila() + var, getColumna() - var);
        }
        if ((super.getFila() == 1 || super.getFila() == 6) && queHay(getFila() + var, getColumna()) == null)
            casillaVisitable(resultado, getFila() + 2 * var, getColumna());
        return resultado;
    }
}